var express = require('express');
var app = express();
var fs = require("fs");
var cors = require('cors');
app.use(cors());
var mysql = require('mysql');
var req_dt = "";
var inp_user = "";
var inp_pass = ""
var login = false;
var login_html = ""
var mysql_user=process.env.mysql_user
var mysql_pass=process.env.mysql_pass

const { Stream } = require('stream');
const { TextEncoder } = require('util');
const { log } = require('console');

var test = "jjjj"
app.get('/', (req, res) => {
    fs.readFile('login.html', (err, data) => {
        if (err) throw err;
        res.write(data)
        res.end('');
    })
});

app.get('/select_date', (req, res) => {

    fs.readFile('select_date.html', (err, data) => {
        if (err) throw err;
        let decoder = new TextDecoder();
        let user_array = new Uint8Array(req.query.user.split(','));
        let pass_array = new Uint8Array(req.query.pass.split(','));
        inp_user = decoder.decode(user_array);
        inp_pass = decoder.decode(pass_array);
        console.log(`${inp_user} ${inp_pass}`)
        uservalidation(req, res, data);


    });
});


function uservalidation(req, res, data) {

    getuser().then((d) => {

        if (d.length > 0) {
            login_html = data.toString();
            login_html = login_html.replace('<h1></h1>', `<h1 style='text-align: center;font-weight:bolder'>Welcome ${inp_user}</h1>`)
            res.write(login_html);

            res.end('');
        } else {
            res.send("<h1 style='text-align: center;font-weight:bolder;color: red'>Bad User or Password</h1>")
        }
    });
}

function getuser() {
    var connection = mysql.createConnection({
        host: 'localhost',
        user: `${mysql_user}`,
        password: `${mysql_pass}`,
        database: 'inventory'
    });
    
   console.log(connection);
    connection.connect();
    return new Promise((resolve, reject) => {
        connection.query(`select * from users where name='${inp_user}' and pass='${inp_pass}'`,
            function(err, data) {
                if (err) {
                    return reject(err);
                }
                resolve(data);
            });
    })
}



app.get('/dates', function(req, res) {;


        req_dt = new Date(req.query.dt).toLocaleDateString('en-us');

        console.log(req_dt);
        readdata(req, res, req_dt);

    }


);

function readdata(req, res, req_dt) {
    var temp = "";
    fs.readFile('part1.html', (err, data) => {
        if (err) throw err;
        let tmp = data.toString();
        tmp = tmp.replace('<h1></h1>', `<h1 style='text-align: center;font-weight:bolder'>User Loggedin: ${inp_user} Date Selected ${req_dt}</h1>`)
        temp += tmp;
        
    })
    getdata().then((data) => {

        if (data.length > 0) {
            //console.log(data);
            temp += "<table class='table table-bordered' style='background-color:aqua' >";
            for (let x of data) {


                temp += "<tr >";
                temp += `<td>${x.ID}</td>`;
                temp += `<td>${x.HostName}</td>`;
                temp += `<td>${x.IP}</td>`;
                temp += `<td>${x.OS}</td>`;
                temp += `<td>${x.Collection_Time}</td>`;
                temp += "</tr>"
            }
            temp += "</table>"
            temp += "</body></html>"
            res.write(temp);
            res.end('');

        } else {
            res.send(`Nothing here for ${req_dt}`)
        }
    })
}


function getdata() {
    var connection = mysql.createConnection({
        host: 'localhost',
        user: `${mysql_user}`,
        password: `${mysql_pass}`,
        database: 'inventory'
    });
    connection.connect();
    return new Promise((resolve, reject) => {
        connection.query(`SELECT * from inventory Where Collection_Time like'${req_dt}%'`,
            function(err, data) {
                if (err) {
                    return reject(err);
                }
                resolve(data);
            });
    })
}

var server = app.listen(7889, function() {

})
