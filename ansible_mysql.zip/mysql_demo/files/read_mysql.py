from datetime import datetime
import mysql.connector
import os,sys,random,json
db = mysql.connector.connect(
  host="localhost",
  user=os.getenv('mysql_user'),
  password=os.getenv('mysql_pass'),
  database="inventory"
)



cursor = db.cursor()

sql = "SELECT * FROM inventory"


cursor.execute(sql)

print(json.dumps(cursor.fetchall()))

