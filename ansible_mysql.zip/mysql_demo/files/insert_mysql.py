from datetime import datetime as dt
import os,sys,random
import mysql.connector
db = mysql.connector.connect(
  host="localhost",
  user=os.getenv('mysql_user'),
  password=os.getenv('mysql_pass'),
  database="inventory"
)



cursor = db.cursor()

sql = "INSERT INTO inventory (ID, Hostname,IPAddress,OS, Collection_Time) VALUES (%s,%s,%s,%s,%s)"
values=(int(random.random()*1000),sys.argv[1],sys.argv[2],sys.argv[3],dt.now().strftime("%m/%d/%Y %H:%M:%S"))

cursor.execute(sql,values)

db.commit()

print(cursor.rowcount)

