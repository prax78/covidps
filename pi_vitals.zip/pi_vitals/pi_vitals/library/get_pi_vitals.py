from ansible.module_utils.basic import AnsibleModule
import psutil

def get_vitals():
    cpu=psutil.cpu_percent(1) * psutil.cpu_count()
    ram=psutil.virtual_memory().percent
    temp=round(int(open('/sys/class/thermal/thermal_zone0/temp').read().splitlines()[0])/1000)
    return {
        'cpu_percent': cpu,
        'ram_percent': ram,
        'pi_temp': temp
    }

def main():
    module_args=dict()
    module=AnsibleModule(
        argument_spec=module_args,
        supports_check_mode= False
    )

    try:
        result= get_vitals()
        module.exit_json(changed=False,result=result)
    except Exception as e:
        module.fail_json(msg=str(e))    
     

if __name__ == '__main__':
    main()
