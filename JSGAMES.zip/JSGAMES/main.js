/** @type {HTMLCanvasElement} */

const bgaudio = new Audio("bg1.wav");
bgaudio.hidden = true;
bgaudio.play();
bgaudio.loop = true;
bgaudio.volume = 0.25;


const canvas = document.getElementById("canvas1");

const ctx = canvas.getContext("2d");


const subZeroSpriteSheet = new Image();
subZeroSpriteSheet.src = "subZeroSpriteSheet.png";
subZeroSpriteSheet.onload = loadImages;


const fire1 = new Image();
fire1.src = "fire1.png";


const zombie = new Image();
zombie.src = "1.png";


let fire1Y = -10;
let cols = 7;
let rows = 2;

let spriteWidth = subZeroSpriteSheet.width / cols;
let spriteHeight = subZeroSpriteSheet.height / rows;

ctx.webkitImageSmoothingEnabled = true;
ctx.imageSmoothingEnabled = true;
let totalFrames = 7;
let currentFrame = 0;
let srcX = 0;

let srcY = 0;
let framesDrawn = 0;
let mvX = 0;
let fire1X = -8000;
let mvY = 130;

var killcounter = 0;
let anim = 0;

let zi = 1;
let ziX = 600;
let ziY = 160;


function animate() {

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    anim = requestAnimationFrame(animate);


    currentFrame = currentFrame % totalFrames;
    srcX = currentFrame * spriteWidth;

    let zimage = new Image();
    zimage.src = `${zi}.png`;

    ctx.save();

    ctx.drawImage(zimage, 15, 11, 100, 100, ziX, ziY, 100, 100);
    ctx.drawImage(subZeroSpriteSheet, srcX, srcY, spriteWidth, spriteHeight, mvX, mvY, spriteWidth, spriteHeight);
    ctx.drawImage(fire1, 0, 0, 5, 5, fire1X, fire1Y, 10, 10);

    ctx.font = "bold  20px serif ";
    ctx.fillStyle = "rgb(128,0,21)";
    ctx.fillText(`Kill: ${killcounter}`, 0, 15, 400);
    ctx.fillStyle = "rgb(0,0,77)";
    ctx.fillText(`Score: ${killcounter*100}`, 0, 35, 400);
    ctx.restore();

    framesDrawn++;
    zi++;
    ziX -= 2;
    if (zi > 10) {
        zi = 1;
    }

    mvX += 1;
    if (mvX >= 600) {;

        mvX = 0;
        cancelAnimationFrame(anim);
        ctx.font = "bold  30px serif ";
        ctx.fillStyle = "red";
        ctx.fillText("GAME OVER", 150, 50, 300);
        bgaudio.volume = 0;
        let glevelaudio = new Audio("glevel.wav");
        glevelaudio.hidden = true;
        glevelaudio.volume = 1;
        glevelaudio.play();
    }


    if (framesDrawn >= 10) {
        currentFrame++;

        framesDrawn = 0;
    }

    fire1X += 5;
    if (fire1X > 600) {
        fire1X = 0;
        fire1Y = -10;
    }
    if (mvX >= 535) {
        ziX = -200;

    }
    if (ziX - fire1X <= -3) {
        killcounter++;
        ziX = 600;
        fire1X = -8000;

    }

    if (ziX - mvX >= 3 && ziX - mvX <= 6) {
        cancelAnimationFrame(anim);
        ctx.font = "bold  50px serif ";
        ctx.fillStyle = "red";
        ctx.fillText("GAME OVER", 150, 50, 300);
        bgaudio.volume = 0;
        let levelfail = new Audio("flevel.wav");
        levelfail.volume = 1;
        levelfail.hidden = true;
        levelfail.play();
    }



}




addEventListener("keydown", e => {
    if (e.key === 'f') {
        //console.log(e.key);
        fired = true;
        fire1X = mvX + 10;
        fire1Y = 180;

        let gunaudio = new Audio("gun.wav");
        gunaudio.play();


    }
});


addEventListener("keyup", e => {
    if (e.key === 'f') {
        //console.log(e.key);
        //fire1Y = 0;
        /*let fireaudio = document.getElementById("gunaudio");
        fireaudio.remove();*/

    }
});



let numOfImages = 1;

function loadImages() {
    if (--numOfImages > 0) return;
    animate();
}